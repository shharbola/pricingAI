import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// In dev, proxy /api to the local FastAPI backend so the app talks to one
// origin. In production the frontend reads VITE_API_BASE (the Cloud Run URL
// of the backend) instead.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { "/api": "http://localhost:8000" },
  },
  build: { outDir: "dist" },
});

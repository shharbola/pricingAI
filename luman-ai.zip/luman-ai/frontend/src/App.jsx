import React, { useEffect, useMemo, useState } from "react";
import {
  LineChart, Line, ScatterChart, Scatter, ComposedChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine,
} from "recharts";
import { api } from "./api.js";

const eur = (n) =>
  n == null ? "—" : "€" + Number(n).toLocaleString("en", { maximumFractionDigits: 0 });
const eur2 = (n) => (n == null ? "—" : "€" + Number(n).toFixed(2));
const pct = (n) => (n == null ? "—" : (n > 0 ? "+" : "") + Number(n).toFixed(1) + "%");

export default function App() {
  const [catalog, setCatalog] = useState(null);
  const [overview, setOverview] = useState(null);
  const [pid, setPid] = useState("SKU-1000");
  const [market, setMarket] = useState("DE");

  useEffect(() => {
    api.catalog().then(setCatalog).catch(console.error);
    api.overview().then(setOverview).catch(console.error);
  }, []);

  return (
    <div className="wrap">
      <header className="masthead">
        <div>
          <h1>LumanAI</h1>
          <div className="sub">
            Sales-driven price recommendations for lighting &amp; home products · DE · FR · CH
          </div>
        </div>
        <ModeTag />
      </header>

      {overview && <SummaryStrip o={overview} />}

      {catalog && (
        <div className="controls">
          <div className="field">
            <label htmlFor="prod">Product</label>
            <select id="prod" value={pid} onChange={(e) => setPid(e.target.value)}>
              {catalog.products.map((p) => (
                <option key={p.product_id} value={p.product_id}>
                  {p.product_id} — {p.product_name} ({p.category})
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="mkt">Market</label>
            <select id="mkt" value={market} onChange={(e) => setMarket(e.target.value)}>
              {catalog.markets.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        </div>
      )}

      <div className="grid2">
        <TrendPanel pid={pid} market={market} />
        <ScatterPanel pid={pid} market={market} />
      </div>

      <OptimizerPanel pid={pid} market={market} />
      <AgentPanel pid={pid} market={market} />
      <EvalPanel />
    </div>
  );
}

function ModeTag() {
  // Reflects whether the backend is calling a real LLM or the offline fallback,
  // read from the agent endpoint the first time it runs. Purely informational.
  const [mode, setMode] = useState(null);
  useEffect(() => {
    api.agents("SKU-1000", "DE").then((r) => setMode(r.mode)).catch(() => {});
  }, []);
  if (!mode) return <div className="mode">connecting…</div>;
  return (
    <div className="mode">
      agents: <b>{mode === "offline" ? "offline (rule-based)" : mode}</b>
    </div>
  );
}

function SummaryStrip({ o }) {
  const items = [
    ["Rows of daily history", o.n_rows.toLocaleString("en")],
    ["Products × markets", `${o.n_products} × ${o.n_markets}`],
    ["Total revenue (2y)", eur(o.total_revenue_eur)],
    ["Avg. gross margin", (o.avg_margin_pct * 100).toFixed(0) + "%"],
  ];
  return (
    <div className="strip">
      {items.map(([k, v]) => (
        <div className="stat" key={k}>
          <div className="k">{k}</div>
          <div className="v">{v}</div>
        </div>
      ))}
    </div>
  );
}

function usePanelData(fn, deps) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => {
    let live = true;
    setData(null); setErr(null);
    fn().then((d) => live && setData(d)).catch((e) => live && setErr(e.message));
    return () => { live = false; };
  }, deps); // eslint-disable-line
  return [data, err];
}

function TrendPanel({ pid, market }) {
  const [d] = usePanelData(() => api.timeseries(pid, market), [pid, market]);
  return (
    <div className="panel">
      <h2>Price &amp; units over time</h2>
      <p className="note">
        What we charged each day and how much sold. Dips in price line up with jumps in units —
        that co-movement is the signal the model learns.
      </p>
      {!d ? <div className="muted">Loading…</div> : (
        <ResponsiveContainer width="100%" height={230}>
          <ComposedChart data={d.series} margin={{ top: 4, right: 8, left: -8, bottom: 0 }}>
            <CartesianGrid stroke="#eee" vertical={false} />
            <XAxis dataKey="date" tick={{ fontSize: 11 }} minTickGap={48} />
            <YAxis yAxisId="u" tick={{ fontSize: 11 }} />
            <YAxis yAxisId="p" orientation="right" tick={{ fontSize: 11 }} />
            <Tooltip />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Area yAxisId="u" dataKey="units_sold" name="Units" fill="#f5e7cf" stroke="#e6c98a" />
            <Line yAxisId="p" dataKey="unit_price_eur" name="Price €" stroke="#16181d" dot={false} strokeWidth={1.6} />
          </ComposedChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

function ScatterPanel({ pid, market }) {
  const [d] = usePanelData(() => api.scatter(pid, market), [pid, market]);
  return (
    <div className="panel">
      <h2>Price vs demand (weekly)</h2>
      <p className="note">
        Each dot is one week. The cloud slopes down to the right: weeks with higher average
        prices sold fewer units. Steeper slope means more price-sensitive.
      </p>
      {!d ? <div className="muted">Loading…</div> : (
        <ResponsiveContainer width="100%" height={230}>
          <ScatterChart margin={{ top: 4, right: 12, left: -8, bottom: 4 }}>
            <CartesianGrid stroke="#eee" />
            <XAxis type="number" dataKey="avg_price" name="Avg price €" tick={{ fontSize: 11 }}
              domain={["dataMin - 5", "dataMax + 5"]} />
            <YAxis type="number" dataKey="units" name="Units/week" tick={{ fontSize: 11 }} />
            <Tooltip cursor={{ strokeDasharray: "3 3" }} />
            <Scatter data={d.points} fill="#d68a1e" fillOpacity={0.6} />
          </ScatterChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

function OptimizerPanel({ pid, market }) {
  const [d] = usePanelData(() => api.optimize(pid, market), [pid, market]);
  const action = useMemo(() => {
    if (!d) return "hold";
    if (Math.abs(d.price_change_pct) < 1) return "hold";
    return d.price_change_pct > 0 ? "increase" : "decrease";
  }, [d]);

  return (
    <div className="panel">
      <h2>Recommended price</h2>
      <p className="note">
        The model estimates how demand responds to price for this product, then picks the price
        that earns the most profit per day — never below cost, never more than 30% from today's price.
      </p>
      {!d ? <div className="muted">Running model…</div> : (
        <>
          <div className="reco">
            <div className="price-move">
              <span className="from">{eur2(d.current_price)}</span>
              <span className="arrow">→</span>
              <span className="to">{eur2(d.recommended_price)}</span>
            </div>
            <span className={`badge ${action}`}>{action.toUpperCase()} {pct(d.price_change_pct)}</span>
          </div>
          <div className="kv">
            <div><div className="k">Elasticity</div><div className="v">{d.elasticity}</div></div>
            <div><div className="k">Unit cost</div><div className="v">{eur2(d.cost)}</div></div>
            <div><div className="k">Margin now → rec.</div><div className="v">{d.current_margin_pct}% → {d.recommended_margin_pct}%</div></div>
            <div>
              <div className="k">Modelled daily profit</div>
              <div className={`v ${d.profit_uplift_pct > 0 ? "pos" : ""}`}>{pct(d.profit_uplift_pct)}</div>
            </div>
          </div>
          <div style={{ marginTop: 18 }}>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={d.profit_curve} margin={{ top: 4, right: 12, left: -8, bottom: 0 }}>
                <CartesianGrid stroke="#eee" vertical={false} />
                <XAxis dataKey="price" tick={{ fontSize: 11 }} tickFormatter={(v) => "€" + v.toFixed(0)} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => "€" + v.toFixed(0)} />
                <Tooltip formatter={(v) => eur2(v)} labelFormatter={(v) => "Price €" + Number(v).toFixed(2)} />
                <Line dataKey="profit" name="Daily profit €" stroke="#16181d" dot={false} strokeWidth={1.6} />
                <ReferenceLine x={d.recommended_price} stroke="#d68a1e" strokeWidth={2}
                  label={{ value: "optimum", fontSize: 11, fill: "#d68a1e", position: "top" }} />
                <ReferenceLine x={d.current_price} stroke="#9aa2ad" strokeDasharray="4 4"
                  label={{ value: "today", fontSize: 11, fill: "#9aa2ad", position: "insideTopRight" }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </>
      )}
    </div>
  );
}

function AgentPanel({ pid, market }) {
  const [d] = usePanelData(() => api.agents(pid, market), [pid, market]);
  return (
    <div className="panel">
      <h2>How the AI team read it</h2>
      <p className="note">
        Three agents work the same numbers in turn. The analyst proposes a move, the auditor
        pushes back on it, and the strategist makes the call.
      </p>
      {!d ? <div className="muted">Agents thinking…</div> : (
        <>
          <div className="agent analyst">
            <div className="role">Analyst <span>· proposes the move</span></div>
            <p>{d.analyst.rationale}</p>
          </div>
          <div className="agent auditor">
            <div className="role">
              Auditor <span>· risk {d.auditor.risk_level} · {d.auditor.approved ? "approved" : "flagged"}</span>
            </div>
            {d.auditor.concerns?.length ? (
              d.auditor.concerns.map((c, i) => <p key={i} className="concern">⚠ {c}</p>)
            ) : (
              <p>No margin, cost, or plausibility concerns.</p>
            )}
          </div>
          <div className="agent strategist">
            <div className="role">Strategist <span>· final call</span></div>
            <div className="final">
              <div className="g">
                {d.strategist.guidance}
              </div>
              <div className="c">confidence {(d.strategist.confidence * 100).toFixed(0)}%</div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function EvalPanel() {
  const [d, setD] = useState(null);
  const [loading, setLoading] = useState(false);
  const run = () => {
    setLoading(true);
    api.evaluate().then(setD).catch(() => {}).finally(() => setLoading(false));
  };
  return (
    <div className="panel">
      <h2>Output checks</h2>
      <p className="note">
        Before any recommendation is trusted, a script re-checks the agents against the data:
        cited numbers must exist, prices must clear cost, moves must stay in band.
      </p>
      {!d ? (
        <button className="run" onClick={run} disabled={loading}>
          {loading ? "Running…" : "Run checks"}
        </button>
      ) : (
        <>
          <div className="eval-badge">
            <span className={`dot ${d.all_passed ? "ok" : "bad"}`} />
            {d.n_passed}/{d.n_cases} example cases passed all checks
          </div>
          <div style={{ marginTop: 12 }}>
            {d.results.map((r) => (
              <div className="check-row" key={r.case}>
                <span>{r.case} · {r.final_action} · {eur2(r.final_price)}</span>
                <span className={r.passed ? "pass" : "fail"}>{r.passed ? "PASS" : "FAIL"}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// One place that knows how to reach the backend.
// Dev: Vite proxies /api to localhost:8000.
// Prod: set VITE_API_BASE to the backend's Cloud Run URL at build time.
const BASE = import.meta.env.VITE_API_BASE || "";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  return res.json();
}

export const api = {
  catalog: () => get("/api/catalog"),
  overview: () => get("/api/overview"),
  timeseries: (pid, market) =>
    get(`/api/timeseries/${pid}${market ? `?market=${market}` : ""}`),
  scatter: (pid, market) => get(`/api/scatter/${pid}?market=${market}`),
  optimize: (pid, market) => get(`/api/optimize/${pid}?market=${market}`),
  agents: (pid, market) => get(`/api/agents/${pid}?market=${market}`),
  evaluate: () => get("/api/evaluate"),
};

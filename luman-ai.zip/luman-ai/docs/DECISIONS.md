# Design decisions

Short record of the choices that shaped the backend, and the ones I
deliberately didn't make.

## Poisson demand model instead of log-log OLS

The obvious way to estimate elasticity is OLS on `log(units) ~ log(price)`;
the slope is the elasticity. It doesn't work here. `log(0)` is undefined, so
every zero-sales row drops out, and ~36% of rows are zeros. Those zeros
aren't spread evenly - they sit on the high-price, low-demand days, which is
exactly the evidence that price moves demand. Drop them and elasticities
collapse toward zero, products look inelastic, and the optimiser wants to
raise every price to the ceiling.

Fitting it confirms the failure: median elasticity around -0.9, R² near 0.05,
and recommendations pinned at +30%.

A Poisson GLM models the counts directly, so zeros are normal observations.
With a log link, the coefficient on `log(price)` is still the elasticity.
After the switch every product comes back negative (median ~-1.8), pseudo-R²
lands around 0.2, and recommendations split between increases and decreases.

## Fixed effects for market and month

CH sells at higher volume than DE, and December outsells February regardless
of price. Left uncontrolled, the price coefficient soaks up those differences.
Market and month go in as dummies so elasticity reflects price moving within a
market and season, not across them. Ad spend enters as `log(1 + ad_spend)`
because spend is a real demand driver and correlates with price during promos.

## web_sessions is deliberately left out of the model

Sessions look like a strong predictor, but they sit downstream of price: a
price cut drives a promo, which drives traffic, which drives sales. Putting a
mediator on the right-hand side absorbs part of the effect being measured and
biases elasticity toward zero. Sessions appear in the charts as context but
stay out of the causal model.

## Grid search instead of the closed-form optimum

Constant-elasticity profit has a closed-form optimum `p* = cost·ε/(ε+1)`, valid
only for `ε < -1` and unbounded as `ε → -1`. A few products sit near -1. The
grid search evaluates profit at 61 prices between the cost floor and ±30% of
today's price and takes the best. Same answer in the interior, never explodes,
and the guardrails are just the ends of the grid. Runs in microseconds.

## Guardrails: cost floor and ±30% band

This is decision support, not autopilot. Below-cost prices are never right, and
a same-day price double - which an unconstrained optimiser will suggest for a
badly underpriced item - is not something a category manager would ship. The
±30% band keeps every suggestion actionable. Around a third of items reach the
band edge, which is useful signal ("look here first") rather than a defect.

## Three agents, run in sequence

Splitting propose / challenge / decide gives the auditor one job - find
problems - which it does better than a single prompt asked to recommend and
critique itself at once. Sequential rather than a debate loop keeps latency and
cost bounded; three calls is enough for this task. Every number an agent may use
is passed in, so nothing is recalled from training, which is what makes the
grounding check meaningful.

## What I'd add next

- Hierarchical elasticities so low-volume products borrow strength from similar
  ones in their category instead of relying on thin data.
- A cross-price term so a promo on one product accounts for cannibalising its
  siblings.
- A holdout of the last few weeks to report out-of-sample unit prediction error,
  instead of in-sample pseudo-R².
- Caching agent responses per product-market so repeat views don't re-call the LLM.

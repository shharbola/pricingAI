"""Tests that pin the invariants we actually care about.

These run offline (no LLM key needed) and double as a spec for the review:
they state, in code, what "correct" means for the model and the agents.
"""
import warnings

import pytest

warnings.filterwarnings("ignore")

from app import agents, data, evaluate, ml


def test_data_loads():
    cat = data.catalog()
    assert cat["n_rows"] == 131028
    assert len(cat["products"]) == 60
    assert set(cat["markets"]) == {"CH", "DE", "FR"}


def test_elasticities_are_negative():
    # Demand should fall as price rises. If a fit says otherwise, the model
    # (or the data feeding it) is wrong and we want the test to shout.
    fits = ml._fit_all()
    assert len(fits) == 60
    assert all(f["elasticity"] < 0 for f in fits.values())


@pytest.mark.parametrize("pid,market", [("SKU-1000", "DE"), ("SKU-1025", "FR")])
def test_recommendation_respects_guardrails(pid, market):
    r = ml.optimize(pid, market)
    assert r["recommended_price"] >= r["cost"]           # never below cost
    assert abs(r["price_change_pct"]) <= 30 + 1e-6        # within +/-30%
    assert r["projected_daily_profit_eur"] >= r["current_daily_profit_eur"] - 1e-6


def test_agent_pipeline_shape():
    facts = ml.optimize("SKU-1000", "DE")
    out = agents.run_pipeline(facts)
    assert out["analyst"]["recommendation"] in {"increase", "decrease", "hold"}
    assert isinstance(out["auditor"]["approved"], bool)
    assert 0.0 <= out["strategist"]["confidence"] <= 1.0


def test_eval_all_pass():
    rep = evaluate.run_checks()
    assert rep["all_passed"], rep

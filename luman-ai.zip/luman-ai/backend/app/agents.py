"""Three agents that turn one ML result into a pricing decision.

Short sequential pipeline. Each agent has a narrow job and a JSON output the
next stage reads. Three calls keeps latency and cost down.

    facts (from ml.optimize)
        -> Analyst    : reads the numbers, proposes a move + reason
        -> Auditor    : challenges it (margin, cost floor, plausibility,
                        and whether the analyst cited anything not in facts)
        -> Strategist : weighs both, makes the final call + confidence

Agents only get the numbers passed in `facts`; nothing comes from memory.
That's what lets the eval check every cited number against the same set.
"""
from __future__ import annotations

from . import llm

# --- role prompts -----------------------------------------------------------
# Each names the role, the one task, the exact output keys, and the rule to
# only use numbers from FACTS.

ANALYST_SYS = (
    "You are a pricing analyst at a lighting e-commerce group. You receive a "
    "JSON block of model FACTS for one product in one market. Recommend whether "
    "to move the price and explain why in two or three plain sentences a category "
    "manager would understand. Use only numbers that appear in FACTS; never invent "
    "figures. Respond as JSON with keys: recommendation (one of 'increase', "
    "'decrease', 'hold'), rationale (string), cited_numbers (list of the numeric "
    "values from FACTS you referenced)."
)

AUDITOR_SYS = (
    "You are a margin and risk auditor. You receive the model FACTS and the "
    "analyst's DRAFT. Your job is to challenge it. Check that the recommended "
    "price is above cost, that the margin is healthy, that the price move is not "
    "implausibly large, and that every number the analyst cited actually appears "
    "in FACTS. Be concise. Respond as JSON with keys: approved (boolean), "
    "concerns (list of strings, empty if none), risk_level (one of 'low', "
    "'medium', 'high')."
)

STRATEGIST_SYS = (
    "You are the commercial strategist who owns the final call. You receive the "
    "FACTS, the analyst DRAFT, and the auditor REVIEW. Decide the action, set a "
    "confidence between 0 and 1, and write one sentence of guidance for the "
    "category manager. If the auditor did not approve, be conservative. Respond "
    "as JSON with keys: final_action (one of 'increase', 'decrease', 'hold'), "
    "final_price (number), confidence (number 0-1), guidance (string)."
)


# --- offline fallbacks ------------------------------------------------------
# Used when no LLM key is set. Same FACTS in, same JSON shape out, so the app
# still runs offline. Kept simple on purpose - the real reasoning is the LLM's
# job; this just keeps the shape valid.

def _offline_analyst(facts: dict) -> dict:
    chg = facts["price_change_pct"]
    rec = "hold" if abs(chg) < 1 else ("increase" if chg > 0 else "decrease")
    cited = [facts["current_price"], facts["recommended_price"], facts["elasticity"]]
    rationale = (
        f"Estimated price elasticity is {facts['elasticity']}, so demand "
        f"{'responds strongly' if facts['elasticity'] < -1 else 'is fairly inelastic'}. "
        f"The profit-maximising price is {facts['recommended_price']} versus "
        f"{facts['current_price']} today, a {chg}% move, with modelled daily profit "
        f"rising to {facts['projected_daily_profit_eur']}."
    )
    return {"recommendation": rec, "rationale": rationale, "cited_numbers": cited}


def _offline_auditor(facts: dict, draft: dict) -> dict:
    concerns, risk = [], "low"
    if facts["recommended_price"] <= facts["cost"]:
        concerns.append("Recommended price is at or below unit cost.")
        risk = "high"
    if abs(facts["price_change_pct"]) >= 25:
        concerns.append("Price move is large; consider phasing it in.")
        risk = "medium"
    if facts["recommended_margin_pct"] < 20:
        concerns.append("Recommended margin is below 20%.")
        risk = "medium"
    return {"approved": len(concerns) == 0 or risk != "high",
            "concerns": concerns, "risk_level": risk}


def _offline_strategist(facts: dict, draft: dict, review: dict) -> dict:
    approved = review["approved"]
    action = draft["recommendation"] if approved else "hold"
    price = facts["recommended_price"] if approved else facts["current_price"]
    base = 0.7 if approved else 0.4
    conf = round(min(0.95, base + max(0.0, facts["pseudo_r2"])), 2)
    guidance = (
        f"{action.capitalize()} to {price} EUR."
        if action != "hold"
        else f"Hold at {facts['current_price']} EUR pending review."
    )
    if review["concerns"]:
        guidance += " Note: " + review["concerns"][0]
    return {"final_action": action, "final_price": price,
            "confidence": conf, "guidance": guidance}


# --- orchestration ----------------------------------------------------------

def run_pipeline(facts: dict) -> dict:
    """Run the three agents in order, returning each stage.

    We return every stage (not just the final call) so the UI can show the
    reasoning and the eval can check it.
    """
    import json

    analyst = llm.complete_json(
        ANALYST_SYS,
        "FACTS:\n" + json.dumps(facts),
        offline_fn=lambda _u: _offline_analyst(facts),
    )
    auditor = llm.complete_json(
        AUDITOR_SYS,
        "FACTS:\n" + json.dumps(facts) + "\n\nDRAFT:\n" + json.dumps(analyst),
        offline_fn=lambda _u: _offline_auditor(facts, analyst),
    )
    strategist = llm.complete_json(
        STRATEGIST_SYS,
        "FACTS:\n" + json.dumps(facts)
        + "\n\nDRAFT:\n" + json.dumps(analyst)
        + "\n\nREVIEW:\n" + json.dumps(auditor),
        offline_fn=lambda _u: _offline_strategist(facts, analyst, auditor),
    )
    return {
        "facts": facts,
        "analyst": analyst,
        "auditor": auditor,
        "strategist": strategist,
        "mode": "offline" if llm.is_offline() else llm.PROVIDER,
    }

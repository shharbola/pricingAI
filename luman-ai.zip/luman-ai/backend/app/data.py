"""Dataset loading, cleaning, and the aggregations the API serves.

Raw file is daily grain (one row per product per market per day). We load
it once and cache it in memory - at 131k rows / ~11 MB that's cheap and
keeps the endpoints fast enough to fit models on the fly.
"""
from __future__ import annotations

import functools
import os
from pathlib import Path

import numpy as np
import pandas as pd

DATA_PATH = Path(
    os.getenv("DATA_PATH", Path(__file__).resolve().parent.parent / "data" / "pricing_sales_daily.csv")
)


@functools.lru_cache(maxsize=1)
def load() -> pd.DataFrame:
    """Read the CSV once and add the columns we reuse everywhere.

    ad_spend_eur is null on ~15% of rows; here that means "no spend
    attributed" rather than unknown, so fill with 0. revenue/profit/margin
    are derived once so the endpoints and ml.py don't recompute them.
    """
    df = pd.read_csv(DATA_PATH, parse_dates=["date"])
    df["ad_spend_eur"] = df["ad_spend_eur"].fillna(0.0)
    df["revenue_eur"] = df["unit_price_eur"] * df["units_sold"]
    df["profit_eur"] = (df["unit_price_eur"] - df["unit_cost_eur"]) * df["units_sold"]
    df["margin_pct"] = np.where(
        df["unit_price_eur"] > 0,
        (df["unit_price_eur"] - df["unit_cost_eur"]) / df["unit_price_eur"],
        np.nan,
    )
    df["month"] = df["date"].dt.month
    return df


def catalog() -> dict:
    """Distinct filter values the frontend needs to build its controls."""
    df = load()
    products = (
        df[["product_id", "product_name", "category", "brand"]]
        .drop_duplicates()
        .sort_values("product_id")
        .to_dict("records")
    )
    return {
        "products": products,
        "categories": sorted(df["category"].unique().tolist()),
        "brands": sorted(df["brand"].unique().tolist()),
        "markets": sorted(df["market"].unique().tolist()),
        "date_min": df["date"].min().date().isoformat(),
        "date_max": df["date"].max().date().isoformat(),
        "n_rows": int(len(df)),
    }


def overview() -> dict:
    """Headline numbers for the dashboard's summary strip."""
    df = load()
    return {
        "n_rows": int(len(df)),
        "n_products": int(df["product_id"].nunique()),
        "n_markets": int(df["market"].nunique()),
        "total_revenue_eur": float(df["revenue_eur"].sum()),
        "total_profit_eur": float(df["profit_eur"].sum()),
        "total_units": int(df["units_sold"].sum()),
        "avg_margin_pct": float(df["margin_pct"].mean()),
    }


def timeseries(product_id: str, market: str | None = None) -> list[dict]:
    """Daily price and units for one product, optionally one market.

    When no market is given we aggregate: units summed, price weighted by
    units so the line reflects what customers actually paid, not a plain
    average of list prices.
    """
    df = load()
    sub = df[df["product_id"] == product_id]
    if market:
        sub = sub[sub["market"] == market]
    if sub.empty:
        return []

    if market:
        out = sub.sort_values("date")[
            ["date", "unit_price_eur", "unit_cost_eur", "units_sold", "web_sessions", "ad_spend_eur"]
        ]
    else:
        g = sub.groupby("date")
        units = g["units_sold"].sum()
        # units-weighted average price; fall back to simple mean on zero-unit days
        wprice = g.apply(
            lambda x: np.average(x["unit_price_eur"], weights=x["units_sold"])
            if x["units_sold"].sum() > 0
            else x["unit_price_eur"].mean()
        )
        out = pd.DataFrame(
            {
                "date": units.index,
                "unit_price_eur": wprice.values,
                "unit_cost_eur": g["unit_cost_eur"].first().values,
                "units_sold": units.values,
                "web_sessions": g["web_sessions"].sum().values,
                "ad_spend_eur": g["ad_spend_eur"].sum().values,
            }
        ).sort_values("date")

    out = out.copy()
    out["date"] = out["date"].dt.strftime("%Y-%m-%d")
    return out.round(2).to_dict("records")


def price_demand_scatter(product_id: str, market: str) -> list[dict]:
    """Weekly price vs units for one product-market.

    Rolled up to ISO weeks: daily counts (~2 units) are too noisy to read,
    weekly you can actually see the downward price-demand slope.
    """
    df = load()
    sub = df[(df["product_id"] == product_id) & (df["market"] == market)].copy()
    if sub.empty:
        return []
    sub["week"] = sub["date"].dt.to_period("W").dt.start_time
    g = sub.groupby("week").agg(
        avg_price=("unit_price_eur", "mean"),
        units=("units_sold", "sum"),
        sessions=("web_sessions", "sum"),
    ).reset_index()
    g["week"] = g["week"].dt.strftime("%Y-%m-%d")
    return g.round(2).to_dict("records")

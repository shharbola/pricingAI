"""Sanity checks on the agents' output over a few example cases.

Not a framework - just the checks that catch how this agent tends to fail:

  1. grounding    - every number the analyst cites is actually in FACTS
                    (i.e. it read the data instead of making figures up)
  2. cost floor   - final price is not below unit cost
  3. plausibility - final price stays inside the +/-30% band
  4. schema       - each stage returned the keys/ranges we expect

run_checks returns structured results; the CLI (python -m app.evaluate)
prints a pass/fail table and exits non-zero on any failure, so it drops
straight into CI.
"""
from __future__ import annotations

from . import agents, data, ml

PRICE_BAND = ml.PRICE_BAND
_TOL = 0.01  # numbers count as "cited" if within 1% of a fact


def _is_grounded(value: float, facts: dict) -> bool:
    """True if `value` matches any numeric fact within tolerance."""
    for v in facts.values():
        if isinstance(v, (int, float)):
            ref = abs(v) if v else 1.0
            if abs(value - v) <= _TOL * ref:
                return True
    return False


def check_case(product_id: str, market: str) -> dict:
    facts = ml.optimize(product_id, market)
    result = agents.run_pipeline(facts)
    analyst, auditor, strategist = result["analyst"], result["auditor"], result["strategist"]

    checks: list[dict] = []

    def add(name, passed, detail=""):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    # 1. grounding
    ungrounded = [n for n in analyst.get("cited_numbers", []) if not _is_grounded(n, facts)]
    add("grounding", not ungrounded,
        "all cited numbers found in facts" if not ungrounded
        else f"ungrounded numbers: {ungrounded}")

    # 2. cost floor
    fp = strategist.get("final_price", facts["current_price"])
    add("above_cost", fp >= facts["cost"], f"final {fp} vs cost {facts['cost']}")

    # 3. plausibility band
    within = (1 - PRICE_BAND) * facts["current_price"] - _TOL <= fp <= (1 + PRICE_BAND) * facts["current_price"] + _TOL
    add("within_band", within,
        f"final {fp} vs current {facts['current_price']} (+/-{int(PRICE_BAND*100)}%)")

    # 4. schema / ranges
    schema_ok = (
        analyst.get("recommendation") in {"increase", "decrease", "hold"}
        and isinstance(auditor.get("approved"), bool)
        and strategist.get("final_action") in {"increase", "decrease", "hold"}
        and 0.0 <= strategist.get("confidence", -1) <= 1.0
    )
    add("schema", schema_ok, "all stages have expected keys and ranges")

    return {
        "case": f"{product_id}/{market}",
        "passed": all(c["passed"] for c in checks),
        "checks": checks,
        "final_action": strategist.get("final_action"),
        "final_price": fp,
        "confidence": strategist.get("confidence"),
    }


# A spread of cases on purpose: some the model wants to raise, some to cut,
# so the checks are exercised in both directions rather than one.
DEFAULT_CASES = [
    ("SKU-1000", "DE"),   # small increase
    ("SKU-1000", "CH"),   # decrease
    ("SKU-1001", "DE"),   # larger increase
    ("SKU-1003", "CH"),   # larger decrease
    ("SKU-1010", "DE"),   # hits the upper guardrail
]


def run_checks(cases: list[tuple[str, str]] | None = None) -> dict:
    cases = cases or DEFAULT_CASES
    results = [check_case(pid, m) for pid, m in cases]
    n_pass = sum(r["passed"] for r in results)
    return {"n_cases": len(results), "n_passed": n_pass,
            "all_passed": n_pass == len(results), "results": results}


def _cli() -> None:
    rep = run_checks()
    print(f"\nAgent output checks  ({rep['n_passed']}/{rep['n_cases']} cases passed)\n")
    for r in rep["results"]:
        flag = "PASS" if r["passed"] else "FAIL"
        print(f"[{flag}] {r['case']:16s} action={r['final_action']:8s} "
              f"price={r['final_price']:>7} conf={r['confidence']}")
        for c in r["checks"]:
            if not c["passed"]:
                print(f"        - {c['check']}: {c['detail']}")
    print()
    raise SystemExit(0 if rep["all_passed"] else 1)


if __name__ == "__main__":
    # `python -m app.evaluate` from the backend/ directory
    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    _cli()

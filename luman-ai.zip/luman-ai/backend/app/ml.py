"""Demand model and price optimiser.

Demand is a daily unit count: low (mean ~2) and zero on about a third of
rows. A log-log OLS of log(units) on log(price) can't use those zeros
(log 0 is undefined), and they're mostly the high-price / low-demand days,
so dropping them biases elasticity toward zero and most products come out
looking inelastic. A Poisson GLM on the raw counts keeps the zeros; with a
log link the log(price) coefficient is the elasticity directly.

    log(E[units]) = a + eps*log(price) + b*log(1+ad_spend)
                    + market and month fixed effects

One fit per product, with its three markets pooled and market entered as a
fixed effect (so eps isn't confounded by CH selling more than DE, etc.).

Optimiser: for constant-elasticity demand q(p) = q0*(p/p0)^eps, profit is
(p-cost)*q(p). We grid-search rather than use the closed form
p* = cost*eps/(eps+1), which blows up as eps approaches -1. Bounds are the
guardrails: at or above cost, and within +/-30% of the current price.
"""
from __future__ import annotations

import functools

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

from . import data

PRICE_BAND = 0.30  # recommendations stay within +/-30% of current price
RECENT_DAYS = 90  # "current" state = median of the last 90 days


@functools.lru_cache(maxsize=1)
def _fit_all() -> dict:
    """Fit one Poisson demand model per product. Cached for the process life."""
    import warnings
    from statsmodels.tools.sm_exceptions import SingularMatrixWarning

    df = data.load()
    out: dict[str, dict] = {}
    for pid, g in df.groupby("product_id"):
        # Some products have no sales in certain month/market combos, so those
        # dummy columns go collinear and statsmodels warns about rank. IRLS
        # still converges and the log(price) coef stays identified, so silence
        # it rather than drop the controls.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SingularMatrixWarning)
            model = smf.glm(
                "units_sold ~ log_p + log_ad + C(market) + C(month)",
                data=g.assign(
                    log_p=np.log(g["unit_price_eur"]),
                    log_ad=np.log1p(g["ad_spend_eur"]),
                ),
                family=sm.families.Poisson(),
            ).fit()
        eps = float(model.params["log_p"])
        out[pid] = {
            "elasticity": eps,
            "elasticity_se": float(model.bse["log_p"]),
            "pseudo_r2": float(1 - model.llf / model.llnull),
            "n_obs": int(model.nobs),
        }
    return out


def elasticity(product_id: str) -> dict:
    return _fit_all()[product_id]


def _current_state(product_id: str, market: str) -> dict:
    df = data.load()
    sub = df[(df["product_id"] == product_id) & (df["market"] == market)]
    recent = sub.sort_values("date").tail(RECENT_DAYS)
    return {
        "current_price": float(recent["unit_price_eur"].median()),
        "cost": float(sub["unit_cost_eur"].iloc[-1]),
        "baseline_units": float(recent["units_sold"].mean()),
        "recent_avg_units": float(recent["units_sold"].mean()),
    }


def optimize(product_id: str, market: str) -> dict:
    """Profit-maximising price for one product-market.

    Returns every number the agents and eval later use, so there's one
    source of truth for what the agent was shown.
    """
    fit = elasticity(product_id)
    eps = fit["elasticity"]
    st = _current_state(product_id, market)
    cur, cost, base = st["current_price"], st["cost"], st["baseline_units"]

    lo = max(cost * 1.01, cur * (1 - PRICE_BAND))
    hi = cur * (1 + PRICE_BAND)
    grid = np.linspace(lo, hi, 61)

    demand = base * (grid / cur) ** eps            # constant-elasticity demand
    profit = (grid - cost) * demand
    best = int(np.argmax(profit))
    rec_price = float(grid[best])

    cur_profit = (cur - cost) * base
    rec_profit = float(profit[best])
    rec_demand = float(demand[best])

    return {
        "product_id": product_id,
        "market": market,
        "elasticity": round(eps, 3),
        "pseudo_r2": round(fit["pseudo_r2"], 3),
        "cost": round(cost, 2),
        "current_price": round(cur, 2),
        "recommended_price": round(rec_price, 2),
        "price_change_pct": round((rec_price / cur - 1) * 100, 1),
        "current_margin_pct": round((cur - cost) / cur * 100, 1),
        "recommended_margin_pct": round((rec_price - cost) / rec_price * 100, 1),
        "baseline_units": round(base, 2),
        "projected_units": round(rec_demand, 2),
        "current_daily_profit_eur": round(cur_profit, 2),
        "projected_daily_profit_eur": round(rec_profit, 2),
        "profit_uplift_pct": round((rec_profit / cur_profit - 1) * 100, 1)
        if cur_profit > 0
        else None,
        # the curve, so the frontend can draw profit vs price with the optimum marked
        "profit_curve": [
            {"price": round(float(p), 2), "profit": round(float(pr), 2)}
            for p, pr in zip(grid, profit)
        ],
    }


def optimize_many(product_id: str) -> list[dict]:
    df = data.load()
    markets = sorted(df[df["product_id"] == product_id]["market"].unique())
    return [optimize(product_id, m) for m in markets]


def portfolio_summary() -> list[dict]:
    """Compact per-product-market recommendation table for the overview tab."""
    df = data.load()
    rows = []
    for pid in sorted(df["product_id"].unique()):
        name = df[df["product_id"] == pid]["product_name"].iloc[0]
        for r in optimize_many(pid):
            rows.append(
                {
                    "product_id": pid,
                    "product_name": name,
                    "market": r["market"],
                    "elasticity": r["elasticity"],
                    "current_price": r["current_price"],
                    "recommended_price": r["recommended_price"],
                    "price_change_pct": r["price_change_pct"],
                    "profit_uplift_pct": r["profit_uplift_pct"],
                }
            )
    return rows

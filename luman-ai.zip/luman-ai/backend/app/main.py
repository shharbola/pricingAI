"""FastAPI surface for LumanAI.

Endpoints: dataset aggregations for the charts, the ML optimum per
product-market, the agent interpretation, and the output checks.
"""
from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from . import agents, data, evaluate, ml

app = FastAPI(title="LumanAI API", version="1.0.0")

# In production, set ALLOWED_ORIGINS to the deployed frontend URL.
origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/catalog")
def catalog():
    return data.catalog()


@app.get("/api/overview")
def overview():
    return data.overview()


@app.get("/api/timeseries/{product_id}")
def timeseries(product_id: str, market: str | None = None):
    ts = data.timeseries(product_id, market)
    if not ts:
        raise HTTPException(404, f"No data for {product_id}")
    return {"product_id": product_id, "market": market, "series": ts}


@app.get("/api/scatter/{product_id}")
def scatter(product_id: str, market: str):
    pts = data.price_demand_scatter(product_id, market)
    if not pts:
        raise HTTPException(404, f"No data for {product_id}/{market}")
    return {"product_id": product_id, "market": market, "points": pts}


@app.get("/api/optimize/{product_id}")
def optimize(product_id: str, market: str):
    try:
        return ml.optimize(product_id, market)
    except KeyError:
        raise HTTPException(404, f"Unknown product {product_id}")


@app.get("/api/portfolio")
def portfolio():
    return {"recommendations": ml.portfolio_summary()}


@app.get("/api/agents/{product_id}")
def run_agents(product_id: str, market: str):
    """Run the ML optimiser, then the three-agent pipeline on the result."""
    try:
        facts = ml.optimize(product_id, market)
    except KeyError:
        raise HTTPException(404, f"Unknown product {product_id}")
    return agents.run_pipeline(facts)


@app.get("/api/evaluate")
def run_eval():
    return evaluate.run_checks()

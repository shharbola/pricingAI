"""Thin LLM wrapper so the agents don't touch a vendor SDK directly.

One entry point (complete_json). Swapping Gemini for another provider is a
change here and nowhere else. We ask for JSON and parse defensively because
models like to wrap it in ``` fences.

If there's no API key, it falls back to a deterministic rule-based mode so
the app, tests, and eval all run offline (handy for local dev and demos
without burning tokens).
"""
from __future__ import annotations

import json
import os
import re

PROVIDER = os.getenv("LLM_PROVIDER", "gemini").lower()
MODEL = os.getenv("LLM_MODEL", "gemini-2.0-flash")
API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or os.getenv("LLM_API_KEY")


def is_offline() -> bool:
    return not API_KEY


def _extract_json(text: str) -> dict:
    """Pull the first JSON object out of a model response."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n?|\n?```$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            return json.loads(m.group(0))
        raise


def _complete_gemini(system: str, user: str) -> str:
    import google.generativeai as genai

    genai.configure(api_key=API_KEY)
    model = genai.GenerativeModel(MODEL, system_instruction=system)
    resp = model.generate_content(
        user,
        generation_config={"temperature": 0.2, "response_mime_type": "application/json"},
    )
    return resp.text


def complete_json(system: str, user: str, offline_fn=None) -> dict:
    """Return a dict from the model. Falls back to `offline_fn` with no key.

    `offline_fn` takes the user prompt string and returns a dict. Each agent
    supplies its own so the offline path mirrors the shape it expects.
    """
    if is_offline():
        if offline_fn is None:
            raise RuntimeError("No LLM API key set and no offline fallback provided.")
        return offline_fn(user)

    if PROVIDER == "gemini":
        raw = _complete_gemini(system, user)
    else:
        raise ValueError(f"Unsupported LLM_PROVIDER: {PROVIDER}")
    return _extract_json(raw)
